<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

    <link rel="stylesheet" href="css/index.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
</head>
<body>
    <section id="contact">
        <div class="section-header">
            <div class="container">
                <h2>Contact Us</h2>
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
            </div>
        </div>
          
        <div class="container">
            <div class="row">
              
                <div class="contact-info">
                    <div class="contact-info-item">
                        <div class="contact-info-icon">
                            <i class="material-icons">home</i>
                        </div>
                        
                        <div class="contact-info-content">
                            <h4>Address</h4>
                            <p>ABES Institute of Technology<br/> Ghaziabad,Uttar Pradesh<br/></p>
                        </div>
                    </div>
                    
                    <div class="contact-info-item">
                        <div class="contact-info-icon">
                            <i class="material-icons">phone</i>
                        </div>
                        
                        <div class="contact-info-content">
                            <h4>Phone</h4>
                            <p>+91 94520-52586</p>
                        </div>
                    </div>
                    
                    <div class="contact-info-item">
                        <div class="contact-info-icon">
                            <i class="material-icons">email</i>
                        </div>
                        
                        <div class="contact-info-content">
                            <h4>Email</h4>
                            <p>prabhatsinghc00@gmail.com</p>
                        </div>
                    </div>
                </div>
              
                <div class="contact-form">
                    <form action="" id="contact-form">
                        <h2>Send Message</h2>
                        <div class="input-box">
                            <input type="text" required="true" name="">
                            <span>Full Name</span>
                        </div>
                        
                        <div class="input-box">
                            <input type="email" required="true" name="">
                            <span>Email</span>
                        </div>
                        
                        <div class="input-box">
                            <textarea required="true" name=""></textarea>
                            <span>Type your Message...</span>
                        </div>
                        
                        <div class="input-box">
                            <input type="submit" value="Send" name="">
                        </div>
                    </form>
                </div>
              
            </div>
        </div>
    </section>
</body>
</html>