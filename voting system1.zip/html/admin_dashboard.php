<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="Responsive Admin &amp; Dashboard Template based on Bootstrap 5">
	<meta name="author" content="AdminKit">
	<meta name="keywords"
		content="adminkit, bootstrap, bootstrap 5, admin, dashboard, template, responsive, css, sass, html, theme, front-end, ui kit, web">

	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link rel="shortcut icon" href="img/icon-48x48.png" />

	<link rel="canonical" href="https://demo-basic.adminkit.io/" />

	<title>Admin Dashboard</title>

	<link href="css/admin_dashboard.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
</head>

<body>
	<div class="wrapper">
		<nav id="sidebar" class="sidebar js-sidebar">
			<div class="sidebar-content js-simplebar">
				<a class="sidebar-brand" href="index1.php">
					<span class="align-middle">E-Bharat Admin</span>
				</a>

				<ul class="sidebar-nav">
					<li class="sidebar-header">
						Pages
					</li>

					<li class="sidebar-item active">
						<a class="sidebar-link" href="admin_dashboard.php">
							<i class="align-middle" data-feather="sliders"></i> <span class="align-middle">Dashboard</span>
						</a>
					</li>

					<li class="sidebar-item">
						<a class="sidebar-link" href="proceed.php">
							<!--<i class="align-middle" data-feather="user"></i> <span class="align-middle">Profile</span>-->
						</a>
					</li>

					<li class="sidebar-item">
						<a class="sidebar-link" href="candidate_admin.php">
							<i class="align-middle" data-feather="log-in"></i> <span class="align-middle">Candidate</span>
						</a>
					</li>

					<li class="sidebar-item">
						<a class="sidebar-link" href="voters_admin.php">
							<i class="align-middle" data-feather="user-plus"></i> <span class="align-middle">Voters</span>
						</a>
					</li>
					<li class="sidebar-item">
						<a class="sidebar-link" href="result1.php">
							<i class="align-middle" data-feather="award"></i> <span class="align-middle">Result</span>
						</a>
					</li>

					<li class="sidebar-item">
						<a class="sidebar-link" href="index.php">
							<i class="align-middle" data-feather="log-out"></i> <span class="align-middle">Log Out</span>
						</a>
					</li>


			</div>
		</nav>

		<div class="main">
			<nav class="navbar navbar-expand navbar-light navbar-bg">
				<a class="sidebar-toggle js-sidebar-toggle">
					<i class="hamburger align-self-center"></i>
				</a>
				<p style="margin-top: 14px; font-size: 25px;">Dashboard</p>
			</nav>

			<main class="content">
				<div class="row">
					<div class="col-12 col-lg-8 col-xxl-9 d-flex">
						<div class="card flex-fill">
							<div class="card-header">

								<h5 class="card-title mb-0">Elections</h5>
							</div>
							<table class="table table-hover my-0">
								<thead>
									<tr>
										<th>Name</th>
										<th class="d-none d-xl-table-cell">Election Date</th>

										<th>Status</th>
										<th class="d-none d-md-table-cell">Winnig Party</th>
									</tr>
								</thead>
								<tbody>
									<tr>
										<td>Project Apollo</td>
										<td class="d-none d-xl-table-cell">01/01/2021</td>

										<td><span class="badge bg-success">Done</span></td>
										<td class="d-none d-md-table-cell">Vanessa Tucker</td>
									</tr>
									<tr>
										<td>Project Fireball</td>
										<td class="d-none d-xl-table-cell">01/01/2021</td>

										<td><span class="badge bg-danger">Cancelled</span></td>
										<td class="d-none d-md-table-cell">William Harris</td>
									</tr>
									<tr>
										<td>Project Hades</td>
										<td class="d-none d-xl-table-cell">01/01/2021</td>

										<td><span class="badge bg-success">Done</span></td>
										<td class="d-none d-md-table-cell">Sharon Lessman</td>
									</tr>
									<tr>
										<td>Project Nitro</td>
										<td class="d-none d-xl-table-cell">01/01/2021</td>

										<td><span class="badge bg-warning">In progress</span></td>
										<td class="d-none d-md-table-cell">Vanessa Tucker</td>
									</tr>
									<tr>
										<td>Project Phoenix</td>
										<td class="d-none d-xl-table-cell">01/01/2021</td>

										<td><span class="badge bg-success">Done</span></td>
										<td class="d-none d-md-table-cell">William Harris</td>
									</tr>
									<tr>
										<td>Project X</td>
										<td class="d-none d-xl-table-cell">01/01/2021</td>

										<td><span class="badge bg-success">Done</span></td>
										<td class="d-none d-md-table-cell">Sharon Lessman</td>
									</tr>
									<tr>
										<td>Project Romeo</td>
										<td class="d-none d-xl-table-cell">01/01/2021</td>

										<td><span class="badge bg-success">Done</span></td>
										<td class="d-none d-md-table-cell">Christina Mason</td>
									</tr>
									<tr>
										<td>Project Wombat</td>
										<td class="d-none d-xl-table-cell">01/01/2021</td>

										<td><span class="badge bg-warning">In progress</span></td>
										<td class="d-none d-md-table-cell">William Harris</td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>

			</main>

			<footer class="footer">
				<div class="container-fluid">
					<div class="row text-muted">
						<div class="col-6 text-start">
							<p class="mb-0">
								<a class="text-muted" href="#" target="_blank"><strong>E-Bharat</strong></a> - <a class="text-muted"
									href="#" target="_blank"><!--<strong>Prabhat Singh Chauhan</strong>--></a> &copy;
							</p>
						</div>
						<div class="col-6 text-end">
							<ul class="list-inline">
								<li class="list-inline-item">
									<a class="text-muted" href="#" target="_blank">Support</a>
								</li>
								<li class="list-inline-item">
									<a class="text-muted" href="#" target="_blank">Help Center</a>
								</li>
								<li class="list-inline-item">
									<a class="text-muted" href="#" target="_blank">Privacy</a>
								</li>
								<li class="list-inline-item">
									<a class="text-muted" href="#" target="_blank">Terms</a>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</footer>
		</div>
	</div>

	<script src="js/app.js"></script>



</body>

</html>